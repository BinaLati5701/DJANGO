from django.apps import AppConfig


class HrAppConfig(AppConfig):
    name = 'hr_app'
