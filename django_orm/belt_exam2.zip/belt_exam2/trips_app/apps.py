from django.apps import AppConfig


class TripsAppConfig(AppConfig):
    name = 'trips_app'
